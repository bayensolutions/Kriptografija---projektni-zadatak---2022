import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;

public class Quiz {
    public static String QUESTIONS_PATH = ".\\questions\\";
    public static String IMAGES_PATH = ".\\images\\";

    public static <BufferedImage> void steganographyHide() {

        List<String> questions=null;
        try {
            questions = Files.readAllLines(Paths.get(QUESTIONS_PATH + "pitanja.txt"));
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        int number = 0;
        for (String question : questions) {
            number++;
            System.out.println(number);
            System.out.println(question);
            try {
                BufferedImage input=(BufferedImage) ImageIO.read(new File(IMAGES_PATH+number+".png"));
                BufferedImage output=null;
                if(new Steganography().encode(input, output, ((java.awt.image.BufferedImage) input).getWidth(), ((java.awt.image.BufferedImage) input).getHeight(), question, QUESTIONS_PATH+number+".png"));
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            

        }
    }
}
